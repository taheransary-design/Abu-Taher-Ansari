Upload this index.html to the root of your GitHub repository.
